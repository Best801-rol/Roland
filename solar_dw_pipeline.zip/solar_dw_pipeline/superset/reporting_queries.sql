-- Dataset 1 : chiffre d'affaires par filiale
SELECT filiale, nombre_ventes, chiffre_affaires, montant_moyen
FROM mart.ca_par_filiale;

-- Dataset 2 : évolution mensuelle du chiffre d'affaires
SELECT mois, filiale, chiffre_affaires, nombre_ventes, quantite_vendue, montant_moyen
FROM mart.performance_ventes_mensuelle
ORDER BY mois, filiale;

-- Dataset 3 : chiffre d'affaires par produit (dataset SQL virtuel possible)
SELECT filiale, produit, SUM(quantite) AS quantite_vendue,
       SUM(montant) AS chiffre_affaires, COUNT(*) AS nombre_ventes
FROM core.ventes
GROUP BY filiale, produit
ORDER BY chiffre_affaires DESC;

-- Dataset 4 : suivi des contrats de crédit par filiale
SELECT filiale, COUNT(*) AS nombre_contrats,
       SUM(montant_credit) AS encours_credit_initial_montant
FROM core.contrats_credit
GROUP BY filiale;
