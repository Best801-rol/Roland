CREATE SCHEMA IF NOT EXISTS raw;
CREATE SCHEMA IF NOT EXISTS audit_data;
CREATE SCHEMA IF NOT EXISTS core;
CREATE SCHEMA IF NOT EXISTS mart;

CREATE TABLE IF NOT EXISTS raw.crm_clients (
    id_client TEXT,
    nom TEXT,
    filiale TEXT,
    date_creation TEXT,
    batch_id TEXT,
    loaded_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS raw.erp_ventes (
    id_vente TEXT,
    id_client TEXT,
    date_vente TEXT,
    produit TEXT,
    quantite TEXT,
    montant TEXT,
    filiale TEXT,
    batch_id TEXT,
    loaded_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS raw.contrats_credit (
    id_contrat TEXT,
    id_client TEXT,
    id_vente TEXT,
    date_contrat TEXT,
    montant_credit TEXT,
    duree_mois TEXT,
    filiale TEXT,
    batch_id TEXT,
    loaded_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS audit_data.quality_results (
    quality_id BIGSERIAL PRIMARY KEY,
    batch_id TEXT NOT NULL,
    source_table TEXT NOT NULL,
    record_id TEXT,
    rule_name TEXT NOT NULL,
    severity TEXT NOT NULL,
    description TEXT NOT NULL,
    checked_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS core.clients (
    id_client TEXT PRIMARY KEY,
    nom TEXT NOT NULL,
    filiale TEXT NOT NULL CHECK (filiale IN ('CIV','TGO')),
    date_creation DATE,
    source_batch_id TEXT,
    loaded_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS core.ventes (
    id_vente TEXT PRIMARY KEY,
    id_client TEXT NOT NULL REFERENCES core.clients(id_client),
    date_vente DATE NOT NULL,
    produit TEXT NOT NULL,
    quantite INTEGER NOT NULL CHECK (quantite > 0),
    montant NUMERIC(15,2) NOT NULL CHECK (montant >= 0),
    filiale TEXT NOT NULL CHECK (filiale IN ('CIV','TGO')),
    source_batch_id TEXT,
    loaded_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS core.contrats_credit (
    id_contrat TEXT PRIMARY KEY,
    id_client TEXT NOT NULL REFERENCES core.clients(id_client),
    id_vente TEXT NOT NULL REFERENCES core.ventes(id_vente),
    date_contrat DATE NOT NULL,
    montant_credit NUMERIC(15,2) NOT NULL CHECK (montant_credit > 0),
    duree_mois INTEGER NOT NULL CHECK (duree_mois > 0),
    filiale TEXT NOT NULL CHECK (filiale IN ('CIV','TGO')),
    source_batch_id TEXT,
    loaded_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS mart.ca_par_filiale (
    filiale TEXT PRIMARY KEY,
    nombre_ventes BIGINT NOT NULL,
    chiffre_affaires NUMERIC(18,2) NOT NULL,
    montant_moyen NUMERIC(18,2) NOT NULL,
    rafraichi_le TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS mart.performance_ventes_mensuelle (
    mois DATE NOT NULL,
    filiale TEXT NOT NULL,
    nombre_ventes BIGINT NOT NULL,
    chiffre_affaires NUMERIC(18,2) NOT NULL,
    quantite_vendue BIGINT NOT NULL,
    montant_moyen NUMERIC(18,2) NOT NULL,
    rafraichi_le TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (mois, filiale)
);
