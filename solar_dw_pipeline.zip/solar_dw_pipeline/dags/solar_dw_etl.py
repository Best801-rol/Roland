from __future__ import annotations

import os
import uuid
from datetime import datetime, timedelta

import pandas as pd
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook

CONN_ID = "solar_postgres"
SOURCE_DIR = os.environ.get("SOURCE_DATA_DIR", "/opt/airflow/data")


def run_sql_file(path: str) -> None:
    hook = PostgresHook(postgres_conn_id=CONN_ID)
    with open(path, "r", encoding="utf-8") as f:
        sql = f.read()
    hook.run(sql, split_statements=True)


def create_schemas_tables(**context):
    # In production, package SQL files with the DAG or use an absolute configured path.
    sql_path = os.environ.get("SOLAR_DDL_PATH", "/opt/airflow/sql/00_create_schemas_tables.sql")
    run_sql_file(sql_path)


def load_csv_to_raw(filename: str, table: str, columns: list[str], **context):
    batch_id = context["run_id"]
    path = os.path.join(SOURCE_DIR, filename)
    if not os.path.isfile(path):
        raise FileNotFoundError(f"Fichier source introuvable : {path}")

    df = pd.read_csv(path, dtype=str, keep_default_na=False)
    for col in columns:
        if col not in df.columns:
            raise ValueError(f"Colonne obligatoire absente : {col} dans {filename}")

    df = df[columns].copy()
    df["batch_id"] = batch_id

    hook = PostgresHook(postgres_conn_id=CONN_ID)
    engine = hook.get_sqlalchemy_engine()
    # Démo seulement : remplacement complet des tables raw à chaque run.
    # Pour la production, utiliser une stratégie incrémentale / staging par batch.
    with engine.begin() as conn:
        conn.exec_driver_sql(f"DELETE FROM {table}")
        df.to_sql(
            name=table.split(".")[1],
            schema=table.split(".")[0],
            con=conn,
            if_exists="append",
            index=False,
            method="multi",
            chunksize=1000,
        )


def extract_crm_to_raw(**context):
    load_csv_to_raw(
        "crm_clients.csv", "raw.crm_clients",
        ["id_client", "nom", "filiale", "date_creation"], **context
    )


def extract_sales_to_raw(**context):
    load_csv_to_raw(
        "erp_ventes.csv", "raw.erp_ventes",
        ["id_vente", "id_client", "date_vente", "produit", "quantite", "montant", "filiale"], **context
    )


def extract_contracts_to_raw(**context):
    load_csv_to_raw(
        "contrats_credit.csv", "raw.contrats_credit",
        ["id_contrat", "id_client", "id_vente", "date_contrat", "montant_credit", "duree_mois", "filiale"], **context
    )


def quality_checks(**context):
    batch_id = context["run_id"]
    hook = PostgresHook(postgres_conn_id=CONN_ID)
    sql = """
    INSERT INTO audit_data.quality_results
      (batch_id, source_table, record_id, rule_name, severity, description)
    SELECT %(batch_id)s, 'raw.erp_ventes', v.id_vente,
           'CLIENT_INCONNU', 'ERROR',
           'La vente référence un client absent de raw.crm_clients'
    FROM raw.erp_ventes v
    LEFT JOIN raw.crm_clients c ON c.id_client = v.id_client
    WHERE c.id_client IS NULL AND v.batch_id = %(batch_id)s;

    INSERT INTO audit_data.quality_results
      (batch_id, source_table, record_id, rule_name, severity, description)
    SELECT %(batch_id)s, 'raw.erp_ventes', id_vente,
           'QUANTITE_NON_POSITIVE', 'ERROR',
           'La quantité doit être strictement positive'
    FROM raw.erp_ventes
    WHERE batch_id = %(batch_id)s
      AND (NULLIF(quantite, '') IS NULL OR quantite !~ '^[0-9]+$' OR quantite::numeric <= 0);

    INSERT INTO audit_data.quality_results
      (batch_id, source_table, record_id, rule_name, severity, description)
    SELECT %(batch_id)s, 'raw.erp_ventes', id_vente,
           'MONTANT_INVALIDE', 'ERROR',
           'Le montant doit être numérique et positif ou nul'
    FROM raw.erp_ventes
    WHERE batch_id = %(batch_id)s
      AND (NULLIF(montant, '') IS NULL OR montant !~ '^[0-9]+([.][0-9]+)?$' OR montant::numeric < 0);

    INSERT INTO audit_data.quality_results
      (batch_id, source_table, record_id, rule_name, severity, description)
    SELECT %(batch_id)s, 'raw.crm_clients', id_client,
           'FILIALE_INVALIDE', 'ERROR',
           'La filiale doit être CIV ou TGO'
    FROM raw.crm_clients
    WHERE batch_id = %(batch_id)s AND filiale NOT IN ('CIV','TGO');
    """
    hook.run(sql, parameters={"batch_id": batch_id}, split_statements=True)


def load_core(**context):
    batch_id = context["run_id"]
    hook = PostgresHook(postgres_conn_id=CONN_ID)

    # Les contrôles de qualité excluent les clients mal formés.
    clients_sql = """
    INSERT INTO core.clients (id_client, nom, filiale, date_creation, source_batch_id)
    SELECT DISTINCT ON (id_client)
      id_client, NULLIF(nom, ''), filiale,
      CASE WHEN date_creation ~ '^\\d{4}-\\d{2}-\\d{2}$' THEN date_creation::date ELSE NULL END,
      batch_id
    FROM raw.crm_clients
    WHERE batch_id = %(batch_id)s
      AND id_client <> '' AND nom <> '' AND filiale IN ('CIV','TGO')
    ORDER BY id_client, loaded_at DESC
    ON CONFLICT (id_client) DO UPDATE SET
      nom = EXCLUDED.nom, filiale = EXCLUDED.filiale,
      date_creation = EXCLUDED.date_creation,
      source_batch_id = EXCLUDED.source_batch_id, loaded_at = NOW();
    """
    hook.run(clients_sql, parameters={"batch_id": batch_id})

    sales_sql = """
    INSERT INTO core.ventes
      (id_vente, id_client, date_vente, produit, quantite, montant, filiale, source_batch_id)
    SELECT DISTINCT ON (v.id_vente)
      v.id_vente, v.id_client, v.date_vente::date, v.produit,
      v.quantite::integer, v.montant::numeric(15,2), v.filiale, v.batch_id
    FROM raw.erp_ventes v
    JOIN core.clients c ON c.id_client = v.id_client
    WHERE v.batch_id = %(batch_id)s
      AND v.id_vente <> '' AND v.produit <> ''
      AND v.date_vente ~ '^\\d{4}-\\d{2}-\\d{2}$'
      AND v.quantite ~ '^[0-9]+$' AND v.quantite::numeric > 0
      AND v.montant ~ '^[0-9]+([.][0-9]+)?$' AND v.montant::numeric >= 0
      AND v.filiale IN ('CIV','TGO')
    ORDER BY v.id_vente, v.loaded_at DESC
    ON CONFLICT (id_vente) DO UPDATE SET
      id_client = EXCLUDED.id_client, date_vente = EXCLUDED.date_vente,
      produit = EXCLUDED.produit, quantite = EXCLUDED.quantite,
      montant = EXCLUDED.montant, filiale = EXCLUDED.filiale,
      source_batch_id = EXCLUDED.source_batch_id, loaded_at = NOW();
    """
    hook.run(sales_sql, parameters={"batch_id": batch_id})

    contracts_sql = """
    INSERT INTO core.contrats_credit
      (id_contrat, id_client, id_vente, date_contrat, montant_credit, duree_mois, filiale, source_batch_id)
    SELECT DISTINCT ON (k.id_contrat)
      k.id_contrat, k.id_client, k.id_vente, k.date_contrat::date,
      k.montant_credit::numeric(15,2), k.duree_mois::integer, k.filiale, k.batch_id
    FROM raw.contrats_credit k
    JOIN core.clients c ON c.id_client = k.id_client
    JOIN core.ventes v ON v.id_vente = k.id_vente AND v.id_client = k.id_client
    WHERE k.batch_id = %(batch_id)s
      AND k.id_contrat <> ''
      AND k.date_contrat ~ '^\\d{4}-\\d{2}-\\d{2}$'
      AND k.montant_credit ~ '^[0-9]+([.][0-9]+)?$' AND k.montant_credit::numeric > 0
      AND k.duree_mois ~ '^[0-9]+$' AND k.duree_mois::numeric > 0
      AND k.filiale IN ('CIV','TGO')
    ORDER BY k.id_contrat, k.loaded_at DESC
    ON CONFLICT (id_contrat) DO UPDATE SET
      id_client = EXCLUDED.id_client, id_vente = EXCLUDED.id_vente,
      date_contrat = EXCLUDED.date_contrat, montant_credit = EXCLUDED.montant_credit,
      duree_mois = EXCLUDED.duree_mois, filiale = EXCLUDED.filiale,
      source_batch_id = EXCLUDED.source_batch_id, loaded_at = NOW();
    """
    hook.run(contracts_sql, parameters={"batch_id": batch_id})


def build_marts(**context):
    hook = PostgresHook(postgres_conn_id=CONN_ID)
    sql = """
    TRUNCATE TABLE mart.ca_par_filiale;
    INSERT INTO mart.ca_par_filiale
      (filiale, nombre_ventes, chiffre_affaires, montant_moyen, rafraichi_le)
    SELECT filiale, COUNT(*), COALESCE(SUM(montant),0),
           COALESCE(AVG(montant),0), NOW()
    FROM core.ventes
    GROUP BY filiale;

    TRUNCATE TABLE mart.performance_ventes_mensuelle;
    INSERT INTO mart.performance_ventes_mensuelle
      (mois, filiale, nombre_ventes, chiffre_affaires, quantite_vendue, montant_moyen, rafraichi_le)
    SELECT DATE_TRUNC('month', date_vente)::date, filiale, COUNT(*),
           COALESCE(SUM(montant),0), COALESCE(SUM(quantite),0),
           COALESCE(AVG(montant),0), NOW()
    FROM core.ventes
    GROUP BY DATE_TRUNC('month', date_vente)::date, filiale;
    """
    hook.run(sql, split_statements=True)


with DAG(
    dag_id="solar_dw_etl",
    description="ETL démonstration CSV -> PostgreSQL DW -> tables de reporting",
    start_date=datetime(2026, 1, 1),
    schedule="@daily",
    catchup=False,
    default_args={
        "owner": "data-team",
        "retries": 2,
        "retry_delay": timedelta(minutes=3),
    },
    tags=["solar", "etl", "postgres", "superset"],
) as dag:
    ddl = PythonOperator(task_id="create_schemas_tables", python_callable=create_schemas_tables)
    crm = PythonOperator(task_id="extract_crm_to_raw", python_callable=extract_crm_to_raw)
    sales = PythonOperator(task_id="extract_sales_to_raw", python_callable=extract_sales_to_raw)
    contracts = PythonOperator(task_id="extract_contracts_to_raw", python_callable=extract_contracts_to_raw)
    quality = PythonOperator(task_id="quality_checks", python_callable=quality_checks)
    core = PythonOperator(task_id="load_core", python_callable=load_core)
    marts = PythonOperator(task_id="build_marts", python_callable=build_marts)

    ddl >> [crm, sales, contracts] >> quality >> core >> marts
