# Solar DW ETL — Python, Apache Airflow, PostgreSQL, Apache Superset

Prototype pédagogique complet pour une entreprise de distribution d'équipements solaires à crédit (filiales CIV et TGO).

## Architecture

CSV (exemple de sources CRM / ERP / contrats)
  -> Airflow DAG `solar_dw_etl`
  -> Python charge les tables `raw`
  -> SQL valide et alimente `core`
  -> SQL construit `mart`
  -> Superset se connecte à PostgreSQL et lit `mart`

> Les fichiers CSV servent de sources de démonstration. En production, remplacer `extract_to_raw()` par des appels API (`requests`) ou une extraction depuis les bases réelles. Ne jamais mettre de mots de passe dans le code.

## 1. Préparer les fichiers sources

Les exemples sont dans `data/` :
- `crm_clients.csv`
- `erp_ventes.csv`
- `contrats_credit.csv`

Ils sont copiés dans le conteneur Airflow par Docker Compose (ou place-les dans le répertoire configuré par `SOURCE_DATA_DIR`).

## 2. Créer la base et les tables

Exécuter `sql/00_create_schemas_tables.sql` dans PostgreSQL, par exemple :

```bash
psql -h localhost -U solar_user -d solar_dw -f sql/00_create_schemas_tables.sql
```

Le script est aussi appelé par le DAG au démarrage, de façon idempotente.

## 3. Configurer Airflow

Créer une connexion Airflow :
- **Connection Id** : `solar_postgres`
- **Connection Type** : `Postgres`
- **Host** : `postgres` (si Airflow est dans Docker sur le même réseau) ou `localhost` (si Airflow tourne localement)
- **Database** : `solar_dw`
- **Login** : `solar_user`
- **Password** : `change_me`
- **Port** : `5432`

Installer les dépendances dans l'environnement Airflow :
`apache-airflow-providers-postgres`, `pandas`, `psycopg2-binary`.

Variables d'environnement optionnelles :
- `SOURCE_DATA_DIR=/opt/airflow/data`
- `SOLAR_BATCH_ID` est créé automatiquement par le DAG à chaque exécution.

Le DAG se trouve dans `dags/solar_dw_etl.py`. Copier ce fichier dans le dossier `dags/` de ton installation Airflow.

## 4. Lancer le pipeline

Dans l'interface Airflow :
1. Activer `solar_dw_etl`.
2. Cliquer sur **Trigger DAG**.
3. Ouvrir le graphe et vérifier l'état des tâches.
4. Consulter les logs si une tâche échoue.

Ordre du pipeline :
1. `create_schemas_tables`
2. `extract_crm_to_raw`, `extract_sales_to_raw`, `extract_contracts_to_raw` (en parallèle)
3. `quality_checks`
4. `load_core`
5. `build_marts`

Le chargement `raw` est idempotent pour le jeu de démonstration : chaque exécution vide puis recharge les tables raw. Pour une vraie production, remplacer ce comportement par un chargement incrémental ou historisé, et définir une clé métier stable.

## 5. Vérifier les résultats dans PostgreSQL

```sql
SELECT * FROM raw.crm_clients;
SELECT * FROM raw.erp_ventes;
SELECT * FROM audit_data.quality_results ORDER BY checked_at DESC;
SELECT * FROM core.ventes;
SELECT * FROM mart.ca_par_filiale;
SELECT * FROM mart.performance_ventes_mensuelle;
```

Les anomalies sont enregistrées dans `audit_data.quality_results`. Les lignes ventes invalides (client absent, montant négatif ou date invalide) ne sont pas chargées dans `core.ventes`. Les contrôles de qualité n'arrêtent pas le pipeline pour permettre le reporting des données valides, mais les résultats doivent être surveillés.

## 6. Connecter Apache Superset

Dans Superset, ajouter une base de données PostgreSQL avec l'URI SQLAlchemy :

`postgresql+psycopg2://solar_user:change_me@postgres:5432/solar_dw`

Si Superset tourne hors Docker, remplacer `postgres` par `localhost`.

Créer les datasets sur :
- `mart.ca_par_filiale`
- `mart.performance_ventes_mensuelle`

Créer ensuite des graphiques :
- Chiffre d'affaires par filiale
- Chiffre d'affaires mensuel
- Nombre de ventes par filiale
- Montant moyen par vente

SQL utiles : `superset/reporting_queries.sql`.

## Important avant production

- Remplacer les CSV de démonstration par des connecteurs CRM/ERP/contrats réels.
- Stocker les secrets dans les connexions Airflow / un gestionnaire de secrets.
- Ajouter les règles métier, le suivi des volumes, des alertes email/Teams et des tests.
- Prévoir incrémental, historique, déduplication, droits PostgreSQL, sauvegardes et monitoring.
- Les données clients sont sensibles : appliquer le principe du moindre privilège et masquer les données personnelles dans les rapports.
